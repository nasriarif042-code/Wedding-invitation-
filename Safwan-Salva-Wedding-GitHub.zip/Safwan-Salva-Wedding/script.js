const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const sections=$$(".section"), music=$("#music"), openBtn=$("#openBtn");
let opened=false, autoTimer=null, suppressScroll=false, currentIndex=0;

function activateSection(section){
  sections.forEach(s=>s.classList.remove("active"));
  if(section) section.classList.add("active");
}
function scrollToSection(index, smooth=true){
  index=Math.max(0,Math.min(index,sections.length-1));
  currentIndex=index;
  sections[index].scrollIntoView({behavior:smooth?"smooth":"auto",block:"start"});
  activateSection(sections[index]);
}
function scheduleNext(){
  clearTimeout(autoTimer);
  if(!opened || currentIndex>=sections.length-1)return;
  const ms=Number(sections[currentIndex].dataset.duration||0);
  if(ms>0) autoTimer=setTimeout(()=>scrollToSection(currentIndex+1),ms);
}
function resetTimer(){
  clearTimeout(autoTimer);
  scheduleNext();
}
function startExperience(){
  if(opened)return;
  opened=true;
  document.body.classList.add("opened");
  openBtn.disabled=true;
  const opening=$("#opening");
  opening.classList.add("curtains-open");
  try{const p=music.play(); if(p?.catch)p.catch(()=>{});}catch(e){}
  setTimeout(()=>scrollToSection(1,false),1700);
}
openBtn.addEventListener("click",startExperience);
openBtn.addEventListener("touchend",e=>{e.preventDefault();startExperience()},{passive:false});

const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting && e.intersectionRatio>.55){
      currentIndex=sections.indexOf(e.target);
      activateSection(e.target);
      if(opened)scheduleNext();
    }
  });
},{threshold:[.55,.8]});
sections.forEach(s=>observer.observe(s));

let touchStartY=0;
window.addEventListener("touchstart",e=>{touchStartY=e.touches[0].clientY},{passive:true});
window.addEventListener("touchend",e=>{
  if(!opened)return;
  const dy=touchStartY-e.changedTouches[0].clientY;
  if(Math.abs(dy)>35){
    clearTimeout(autoTimer);
    if(dy>0)scrollToSection(currentIndex+1);
    else scrollToSection(currentIndex-1);
  }
  setTimeout(resetTimer,700);
},{passive:true});
window.addEventListener("wheel",()=>{if(opened)resetTimer()},{passive:true});

const petals=$("#opening .petals");
for(let i=0;i<34;i++){
  const p=document.createElement("span");
  p.className="petal";
  p.style.left=(Math.random()*100)+"%";
  p.style.width=(6+Math.random()*8)+"px";
  p.style.height=(9+Math.random()*10)+"px";
  p.style.animationDuration=(6+Math.random()*8)+"s";
  p.style.animationDelay=(-Math.random()*12)+"s";
  p.style.setProperty("--drift",((Math.random()-.5)*180)+"px");
  petals.appendChild(p);
}

function initScratch(){
  const c=$("#scratchCanvas"), wrap=c.parentElement, ctx=c.getContext("2d");
  const dpr=Math.max(1,Math.min(2,devicePixelRatio||1));
  const resize=()=>{
    c.width=wrap.clientWidth*dpr;c.height=wrap.clientHeight*dpr;
    c.style.width=wrap.clientWidth+"px";c.style.height=wrap.clientHeight+"px";
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.fillStyle="#8f7880";ctx.fillRect(0,0,wrap.clientWidth,wrap.clientHeight);
    ctx.fillStyle="#d9c7ae";ctx.font="600 11px Georgia";ctx.textAlign="center";ctx.textBaseline="middle";
    ctx.fillText("SCRATCH TO REVEAL",wrap.clientWidth/2,wrap.clientHeight/2);
  };
  resize();addEventListener("resize",resize);
  let drawing=false;
  const scratch=e=>{
    if(!drawing)return;
    const r=c.getBoundingClientRect(), x=(e.clientX??e.touches?.[0]?.clientX)-r.left, y=(e.clientY??e.touches?.[0]?.clientY)-r.top;
    ctx.globalCompositeOperation="destination-out";ctx.beginPath();ctx.arc(x,y,22,0,Math.PI*2);ctx.fill();
  };
  c.addEventListener("pointerdown",e=>{drawing=true;c.setPointerCapture?.(e.pointerId);scratch(e)});
  c.addEventListener("pointermove",scratch);
  c.addEventListener("pointerup",()=>drawing=false);
  c.addEventListener("pointercancel",()=>drawing=false);
}
initScratch();

const target=new Date("2026-10-25T16:30:00+05:30").getTime();
function updateCountdown(){
  let diff=Math.max(0,target-Date.now());
  const s=Math.floor(diff/1000);
  $("#days").textContent=String(Math.floor(s/86400)).padStart(2,"0");
  $("#hours").textContent=String(Math.floor(s%86400/3600)).padStart(2,"0");
  $("#minutes").textContent=String(Math.floor(s%3600/60)).padStart(2,"0");
  $("#seconds").textContent=String(s%60).padStart(2,"0");
}
updateCountdown();setInterval(updateCountdown,1000);

const STORAGE="safwanSalvaResponsesV1";
function getData(){try{return JSON.parse(localStorage.getItem(STORAGE)||"[]")}catch{return[]}}
function saveData(x){localStorage.setItem(STORAGE,JSON.stringify(x))}
let pendingResponse=null;
$$("[data-response]").forEach(btn=>btn.addEventListener("click",()=>{
  const name=$("#guestName").value.trim();
  if(!name){$("#responseStatus").textContent="Please enter your name first.";$("#guestName").focus();return}
  pendingResponse=btn.dataset.response;
  $("#sideRow").classList.remove("hidden");
  $("#responseStatus").textContent="Please choose GROOM or BRIDE.";
}));
$$("[data-side]").forEach(btn=>btn.addEventListener("click",()=>{
  if(!pendingResponse)return;
  const name=$("#guestName").value.trim();
  const data=getData();
  data.push({name,datetime:new Date().toLocaleString("en-IN",{dateStyle:"medium",timeStyle:"short"}),side:btn.dataset.side,response:pendingResponse});
  saveData(data);
  $("#responseStatus").textContent="Your response has been recorded. Thank you. 🤍";
  $("#sideRow").classList.add("hidden");pendingResponse=null;
  $("#guestName").value="";
}));

const modal=$("#dashboardModal");
$("#dashboardLink").addEventListener("click",()=>modal.classList.remove("hidden"));
$("#closeDashboard").addEventListener("click",()=>modal.classList.add("hidden"));
modal.addEventListener("click",e=>{if(e.target===modal)modal.classList.add("hidden")});
$("#loginBtn").addEventListener("click",()=>{
  if($("#dashboardPassword").value==="SafSal2026!"){
    $("#loginPanel").classList.add("hidden");$("#dashboardPanel").classList.remove("hidden");renderDashboard();
  }else $("#loginError").textContent="Incorrect password.";
});
function renderDashboard(){
  const all=getData();
  ["GROOM","BRIDE"].forEach(side=>{
    const rows=all.filter(x=>x.side===side);
    const yes=rows.filter(x=>x.response==="I WILL ATTEND").length;
    $(`#${side.toLowerCase()}Yes`).textContent=yes;
    $(`#${side.toLowerCase()}No`).textContent=rows.length-yes;
    const body=$(`#${side.toLowerCase()}Body`);
    body.innerHTML="";
    rows.forEach(r=>{
      const tr=document.createElement("tr");
      [r.name,r.datetime,r.response].forEach(v=>{const td=document.createElement("td");td.textContent=v;tr.appendChild(td)});
      body.appendChild(tr);
    });
  });
}
$$("[data-export]").forEach(btn=>btn.addEventListener("click",()=>{
  const side=btn.dataset.export, rows=getData().filter(x=>x.side===side);
  const csv=[["Name","Date & Time","Response"],...rows.map(x=>[x.name,x.datetime,x.response])]
    .map(row=>row.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\r\n");
  const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`${side.toLowerCase()}-responses.csv`;a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}));
activateSection($("#opening"));

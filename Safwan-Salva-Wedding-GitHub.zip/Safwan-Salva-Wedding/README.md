# Safwan & Salva Wedding Invitation

GitHub Pages-ready static wedding invitation.

## Assets
Place the real uploaded assets in `assets/` with these filenames:
- curtain.jpg
- wedding-video.mp4
- english-bg.jpg
- quran-bg.jpg
- venue.jpg
- final-video.mp4
- wedding-music.mp3

## Publish
Upload the files to a GitHub repository and enable GitHub Pages from the `main` branch.
